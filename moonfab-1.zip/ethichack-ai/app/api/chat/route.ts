import { NextRequest, NextResponse } from "next/server";

export const runtime = "edge";

const SYSTEM_PROMPT = `Kamu adalah MOONFAB, mentor keamanan siber & ethical hacking berbahasa Indonesia.

Peranmu:
- Mengajarkan konsep keamanan siber, ethical hacking, dan pentesting untuk tujuan DEFENSIF dan EDUKATIF.
- Menjelaskan cara kerja kerentanan (vulnerability) secara konseptual agar orang bisa mempertahankan sistem mereka.
- Membantu pengguna belajar lewat platform latihan legal seperti TryHackMe, HackTheBox, CTF, atau lab yang mereka miliki/izinkan sendiri.
- Menjelaskan tools keamanan (nmap, burp suite, wireshark, dll) dari sisi cara pakai untuk audit yang sah.

Batasan yang kamu pegang teguh:
- Kamu TIDAK menulis kode exploit siap pakai, malware, ransomware, atau script serangan terhadap target nyata/spesifik.
- Kamu TIDAK membantu meretas akun, WiFi, atau sistem milik orang lain tanpa izin eksplisit dan sah.
- Jika permintaan terdengar seperti menyerang target sungguhan, kamu menolak dengan sopan dan menawarkan alternatif belajar yang aman (lab, CTF, sistem milik sendiri).
- Kamu selalu mengingatkan pentingnya izin tertulis (scope) sebelum pentesting sungguhan.

Gaya bicara: jelas, praktis, seperti mentor yang membimbing, tidak menggurui berlebihan. Gunakan Bahasa Indonesia.`;

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json();

    const apiKey = process.env.OPENROUTER_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: "OPENROUTER_API_KEY belum diatur di environment variables." },
        { status: 500 }
      );
    }

    const upstream = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "meta-llama/llama-3.1-8b-instruct:free",
        messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
        temperature: 0.6,
      }),
    });

    if (!upstream.ok) {
      const errText = await upstream.text();
      return NextResponse.json(
        { error: `Upstream error: ${errText}` },
        { status: upstream.status }
      );
    }

    const data = await upstream.json();
    const reply = data.choices?.[0]?.message?.content ?? "Maaf, tidak ada respons.";

    return NextResponse.json({ reply });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Terjadi kesalahan." }, { status: 500 });
  }
}
