"use client";

import { useEffect, useRef, useState } from "react";

type Msg = { role: "user" | "assistant"; content: string };

const STARTER_LOG = [
  "moonfab@core:~$ init session",
  "loading mentor module ..... ok",
  "scope: pendidikan & pertahanan siber saja",
  "session ready.",
];

export default function Home() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [bootDone, setBootDone] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setTimeout(() => setBootDone(true), STARTER_LOG.length * 260 + 200);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  async function send() {
    const text = input.trim();
    if (!text || loading) return;
    const next = [...messages, { role: "user" as const, content: text }];
    setMessages(next);
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next }),
      });
      const data = await res.json();
      setMessages([...next, { role: "assistant", content: data.reply ?? data.error ?? "Terjadi kesalahan." }]);
    } catch (e) {
      setMessages([...next, { role: "assistant", content: "Gagal terhubung ke server. Coba lagi." }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={styles.page}>
      <div style={styles.scanTint} />

      <header style={styles.header}>
        <div className="mono" style={styles.brandRow}>
          <span style={styles.dot} />
          <span style={styles.dot2} />
          <span style={styles.dot3} />
          <span style={{ marginLeft: 12, color: "var(--text-dim)" }}>moonfab://session/local</span>
        </div>
        <h1 className="display" style={styles.brand}>
          MOON<span style={{ color: "var(--amber)" }}>FAB</span>
        </h1>
        <p className="mono" style={styles.tagline}>
          mentor ethical hacking &amp; keamanan siber — belajar bertahan, bukan menyerang
        </p>
      </header>

      <section style={styles.terminal}>
        <div ref={scrollRef} style={styles.log} className="mono">
          {!bootDone &&
            STARTER_LOG.map((line, i) => (
              <div
                key={i}
                style={{
                  ...styles.bootLine,
                  animation: `moonfabFadeIn 0.25s ease forwards`,
                  animationDelay: `${i * 0.26}s`,
                  opacity: 0,
                }}
              >
                {line}
              </div>
            ))}

          {bootDone && messages.length === 0 && (
            <div style={styles.emptyState}>
              <div style={{ color: "var(--text-dim)" }}>
                # mulai dengan satu pertanyaan, contoh:
              </div>
              <div style={{ marginTop: 8 }}>
                {[
                  "Jelaskan cara kerja SQL injection dan cara mencegahnya",
                  "Bagaimana alur pentest yang legal & beretika?",
                  "Apa itu privilege escalation di Linux?",
                ].map((ex) => (
                  <button key={ex} style={styles.exampleBtn} onClick={() => setInput(ex)}>
                    → {ex}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m, i) => (
            <div key={i} style={styles.entry}>
              <span style={m.role === "user" ? styles.promptUser : styles.promptBot}>
                {m.role === "user" ? "you $" : "moonfab >"}
              </span>
              <span style={styles.entryText}>{m.content}</span>
            </div>
          ))}

          {loading && (
            <div style={styles.entry}>
              <span style={styles.promptBot}>moonfab &gt;</span>
              <span style={{ ...styles.entryText, color: "var(--text-dim)" }}>
                menyusun jawaban
                <span style={styles.cursorBlink}>_</span>
              </span>
            </div>
          )}
        </div>

        <div style={styles.inputRow}>
          <span className="mono" style={styles.inputPrompt}>
            you $
          </span>
          <input
            className="mono"
            style={styles.input}
            value={input}
            placeholder="tulis pertanyaan seputar keamanan siber..."
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
          />
          <button style={styles.sendBtn} onClick={send} disabled={loading}>
            kirim
          </button>
        </div>
      </section>

      <footer style={styles.footer} className="mono">
        scope: edukasi & pertahanan siber. tidak untuk menyerang target tanpa izin.
      </footer>

      <style>{`
        @keyframes moonfabFadeIn { to { opacity: 1; } }
        @keyframes moonfabBlink { 0%, 49% { opacity: 1; } 50%, 100% { opacity: 0; } }
      `}</style>
    </main>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "48px 20px 24px",
    position: "relative",
  },
  scanTint: {
    position: "fixed",
    inset: 0,
    pointerEvents: "none",
    background:
      "radial-gradient(60% 40% at 50% 0%, rgba(232,163,61,0.06), transparent 70%)",
  },
  header: { textAlign: "center", marginBottom: 28, maxWidth: 640 },
  brandRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: 12,
    marginBottom: 18,
  },
  dot: { width: 8, height: 8, borderRadius: 99, background: "var(--danger)", display: "inline-block" },
  dot2: { width: 8, height: 8, borderRadius: 99, background: "var(--amber)", display: "inline-block", marginLeft: 6 },
  dot3: { width: 8, height: 8, borderRadius: 99, background: "var(--teal)", display: "inline-block", marginLeft: 6 },
  brand: { fontSize: 42, letterSpacing: "0.02em", margin: 0, fontWeight: 700 },
  tagline: { color: "var(--text-dim)", fontSize: 13, marginTop: 10 },
  terminal: {
    width: "100%",
    maxWidth: 720,
    background: "var(--panel)",
    border: "1px solid var(--panel-line)",
    borderRadius: 10,
    overflow: "hidden",
    boxShadow: "0 20px 60px rgba(0,0,0,0.4)",
  },
  log: {
    height: "56vh",
    minHeight: 320,
    overflowY: "auto",
    padding: 20,
    fontSize: 14,
    lineHeight: 1.7,
  },
  bootLine: { color: "var(--text-dim)" },
  emptyState: { fontSize: 13.5 },
  exampleBtn: {
    display: "block",
    width: "100%",
    textAlign: "left",
    background: "transparent",
    border: "none",
    color: "var(--teal)",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: "6px 0",
    cursor: "pointer",
  },
  entry: { display: "flex", gap: 10, marginBottom: 14, alignItems: "flex-start" },
  promptUser: { color: "var(--teal)", flexShrink: 0 },
  promptBot: { color: "var(--amber)", flexShrink: 0 },
  entryText: { whiteSpace: "pre-wrap", color: "var(--text)" },
  cursorBlink: { animation: "moonfabBlink 1s step-start infinite" },
  inputRow: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    borderTop: "1px solid var(--panel-line)",
    padding: "12px 16px",
    background: "#0d1116",
  },
  inputPrompt: { color: "var(--teal)", fontSize: 14 },
  input: {
    flex: 1,
    background: "transparent",
    border: "none",
    color: "var(--text)",
    fontSize: 14,
    outline: "none",
  },
  sendBtn: {
    background: "var(--amber)",
    color: "#141008",
    border: "none",
    borderRadius: 6,
    padding: "8px 16px",
    fontWeight: 600,
    fontSize: 13,
    cursor: "pointer",
  },
  footer: { marginTop: 20, fontSize: 11, color: "var(--text-dim)", textAlign: "center" },
};
