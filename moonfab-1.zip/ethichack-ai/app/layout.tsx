import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MOONFAB — Mentor Ethical Hacking AI",
  description: "Asisten AI khusus keamanan siber dan ethical hacking, untuk belajar secara aman dan legal.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
