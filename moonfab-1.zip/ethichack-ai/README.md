# MOONFAB

Website chatbot AI mentor ethical hacking & keamanan siber (Bahasa Indonesia), dibangun dengan Next.js dan siap deploy di Vercel. Otak AI-nya memakai OpenRouter (model gratis), bukan model buatan sendiri.

## Cara pakai dari HP (tanpa laptop)

### 1. Buat akun & ambil API key OpenRouter (gratis)
1. Buka https://openrouter.ai lewat browser HP, daftar/login.
2. Buka menu **Keys**, buat API key baru, salin (simpan baik-baik, hanya muncul sekali).
3. Model yang dipakai di script ini: `meta-llama/llama-3.1-8b-instruct:free` — gratis. Kamu bisa ganti ke model gratis lain di https://openrouter.ai/models (filter "free").

### 2. Upload project ke GitHub
1. Buat akun GitHub kalau belum punya (bisa dari app GitHub di HP atau browser).
2. Buat repository baru, misal `moonfab`.
3. Upload semua file di folder ini ke repo tersebut (di app GitHub: tombol "+" → "Upload files", lalu pilih semua file/folder dari hasil unduhan ini).

### 3. Deploy ke Vercel
1. Buka https://vercel.com lewat browser HP, daftar/login pakai akun GitHub (gratis).
2. Klik **Add New → Project**, pilih repo `moonfab` yang tadi diupload.
3. Sebelum klik Deploy, buka bagian **Environment Variables**, tambahkan:
   - Name: `OPENROUTER_API_KEY`
   - Value: (API key dari OpenRouter tadi)
4. Klik **Deploy**. Tunggu 1-2 menit sampai selesai.
5. Vercel akan kasih link seperti `https://moonfab.vercel.app` — itu website MOONFAB kamu, sudah live.

## Struktur project
```
ethichack-ai/
├── app/
│   ├── api/chat/route.ts   # backend, panggil OpenRouter
│   ├── layout.tsx          # metadata halaman
│   ├── page.tsx            # UI chat (terminal style)
│   └── globals.css         # warna & font
├── package.json
├── next.config.mjs
├── tsconfig.json
└── README.md
```

## Ganti model AI
Buka `app/api/chat/route.ts`, cari baris:
```ts
model: "meta-llama/llama-3.1-8b-instruct:free",
```
Ganti dengan model gratis lain dari OpenRouter kalau mau coba yang berbeda.

## Ganti kepribadian/aturan AI
Edit variabel `SYSTEM_PROMPT` di file yang sama untuk mengubah gaya bicara atau batasan topik.

## Catatan penting
- Model gratis di OpenRouter punya batas rate/kuota harian — kalau tiba-tiba error, biasanya karena kuota model itu habis; tinggal ganti ke model gratis lain.
- Chatbot ini sengaja dibatasi hanya membantu edukasi & pertahanan siber (bukan bikin exploit/malware untuk target sungguhan), jangan hapus bagian batasan di system prompt.
